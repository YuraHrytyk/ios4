import SwiftUI
import Combine

struct DictionarySearchView: View {

    @StateObject private var viewModel = DictionaryViewModel()
    @FocusState private var isSearchFocused: Bool  

    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea()
                .onTapGesture {
                    isSearchFocused = false
                }

            VStack {
                searchField

                if !viewModel.searchHistory.isEmpty {
                    historySection
                }

                if viewModel.isLoading {
                    ProgressView("Завантаження...")
                        .padding(.top)
                } else if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .padding(.top)
                } else if viewModel.noResults {
                    Text("За цим запитом нічого не знайдено.")
                        .foregroundColor(.secondary)
                        .padding(.top)
                }
               
                if viewModel.definitions.isEmpty &&
                   viewModel.searchQuery.isEmpty &&
                   !viewModel.isLoading &&
                   viewModel.errorMessage == nil {
                    Spacer()
                    emptyStateView
                    Spacer()
                } else {
                    definitionsList
                }
            }
            .padding()
        }
        .navigationTitle("Словник програміста")
    }

    private var searchField: some View {
        HStack {
            HStack {
                TextField("Введіть технічний термін...", text: $viewModel.searchQuery)
                    .textFieldStyle(.plain)              // без вбудованої рамки
                    .focused($isSearchFocused)
                    .onSubmit {
                        Task { await viewModel.search() }
                    }
                if !viewModel.searchQuery.isEmpty {
                    Button {
                        viewModel.searchQuery = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray.opacity(0.4))
            )

            Button {
                Task { await viewModel.search() }
                isSearchFocused = false
            } label: {
                Image(systemName: "magnifyingglass")
            }
            .buttonStyle(.bordered)
        }
    }


    private var historySection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack {
                ForEach(viewModel.searchHistory, id: \.self) { term in
                    Button {
                        viewModel.selectFromHistory(term: term)
                        isSearchFocused = false
                    } label: {
                        Text(term)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(12)
                    }
                }
            }
            .padding(.vertical, 6)
        }
    }

    private var definitionsList: some View {
        List {
            ForEach(viewModel.definitions) { definition in
                NavigationLink {
                    DefinitionDetailView(definition: definition)
                } label: {
                    DefinitionRowView(definition: definition)
                }
            }
        }
        .listStyle(.plain)
        .scrollDismissesKeyboard(.immediately)
        
    }
}
private var emptyStateView: some View {
    VStack(spacing: 16) {
        Image(systemName: "book.fill")
            .font(.system(size: 50))
            .foregroundColor(.accentColor)

        Text("Ласкаво просимо!")
            .font(.title2)
            .fontWeight(.semibold)

        Text("Введіть технічний термін у пошуку, щоб знайти визначення.")
            .font(.subheadline)
            .foregroundColor(.secondary)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 20)
    }
    .padding(.top, 40)
}
