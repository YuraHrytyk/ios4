
import SwiftUI
import UIKit

struct DefinitionDetailView: View {

    let definition: Definition
    @State private var isCopied: Bool = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                Text(definition.word)
                    .font(.largeTitle.bold())

                Text("Визначення")
                    .font(.headline)
                Text(definition.definition)
                    .font(.body)

                if let example = definition.example, !example.isEmpty {
                    Text("Приклад використання")
                        .font(.headline)
                    Text(example)
                        .italic()
                }

                if !definition.author.isEmpty {
                    Text("Автор: \(definition.author)")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                Button {
                    copyToClipboard()
                } label: {
                    Label(isCopied ? "Скопійовано" : "Копіювати визначення",
                          systemImage: "doc.on.doc")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
        .navigationBarTitleDisplayMode(.inline)
    }

    private func copyToClipboard() {
        UIPasteboard.general.string = definition.definition

        withAnimation {
            isCopied = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation {
                isCopied = false
            }
        }
    }
}
