
import SwiftUI

struct DefinitionRowView: View {

    let definition: Definition

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(definition.word)
                .font(.headline)

            Text(definition.definition)
                .font(.subheadline)
                .lineLimit(3)

            HStack(spacing: 12) {
                Label("\(definition.thumbsUp)", systemImage: "hand.thumbsup")
                Label("\(definition.thumbsDown)", systemImage: "hand.thumbsdown")
            }
            .font(.caption)
            .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }
}
