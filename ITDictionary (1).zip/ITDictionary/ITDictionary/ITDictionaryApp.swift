
import SwiftUI

@main
struct ProgrammerDictionaryApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                DictionarySearchView()
            }
        }
    }
}
