
import Foundation

struct DefinitionsResponse: Decodable {
    let list: [Definition]
}

struct Definition: Identifiable, Decodable {
    let id: Int
    let word: String
    let definition: String
    let example: String?
    let author: String
    let thumbsUp: Int
    let thumbsDown: Int
    let writtenOn: Date?

    enum CodingKeys: String, CodingKey {
        case word
        case definition
        case example
        case author
        case thumbsUp = "thumbs_up"
        case thumbsDown = "thumbs_down"
        case writtenOn = "written_on"
        case defid
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        self.word = try container.decode(String.self, forKey: .word)
        self.definition = try container.decode(String.self, forKey: .definition)
        self.example = try container.decodeIfPresent(String.self, forKey: .example)
        self.author = try container.decodeIfPresent(String.self, forKey: .author) ?? ""
        self.thumbsUp = try container.decodeIfPresent(Int.self, forKey: .thumbsUp) ?? 0
        self.thumbsDown = try container.decodeIfPresent(Int.self, forKey: .thumbsDown) ?? 0

        let defId = try container.decodeIfPresent(Int.self, forKey: .defid) ?? Int.random(in: 0...Int.max)
        self.id = defId

        if let dateString = try container.decodeIfPresent(String.self, forKey: .writtenOn) {
            let formatter = ISO8601DateFormatter()
            self.writtenOn = formatter.date(from: dateString)
        } else {
            self.writtenOn = nil
        }
    }
}
