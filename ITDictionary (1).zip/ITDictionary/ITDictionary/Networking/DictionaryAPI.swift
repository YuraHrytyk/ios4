
import Foundation

protocol DictionaryAPIProtocol {
    func search(term: String) async throws -> [Definition]
}

struct UrbanDictionaryAPI: DictionaryAPIProtocol {

    private let baseURL = URL(string: "https://api.urbandictionary.com")!

    func search(term: String) async throws -> [Definition] {
        var components = URLComponents(
            url: baseURL.appendingPathComponent("/v0/define"),
            resolvingAgainstBaseURL: false
        )!

        components.queryItems = [
            URLQueryItem(name: "term", value: term)
        ]

        guard let url = components.url else {
            throw URLError(.badURL)
        }

        let (data, response) = try await URLSession.shared.data(from: url)

        guard let httpResponse = response as? HTTPURLResponse,
              (200..<300).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }

        let decoder = JSONDecoder()
        let apiResponse = try decoder.decode(DefinitionsResponse.self, from: data)
        return apiResponse.list
    }
}
