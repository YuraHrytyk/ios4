import SwiftUI
import Foundation
import Combine
@MainActor
final class DictionaryViewModel: ObservableObject {

    @Published var searchQuery: String = ""
    @Published var definitions: [Definition] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var noResults: Bool = false
    @Published var searchHistory: [String] = []

    private let api: DictionaryAPIProtocol
    private let historyKey = "searchHistoryKey"

    init(api: DictionaryAPIProtocol = UrbanDictionaryAPI()) {
        self.api = api
        loadHistory()
    }

    func search() async {
        let trimmed = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        isLoading = true
        errorMessage = nil
        noResults = false

        do {
            let result = try await api.search(term: trimmed)
            definitions = result
            noResults = result.isEmpty
            updateHistory(with: trimmed)
        } catch {
            errorMessage = "Не вдалося завантажити дані. Спробуйте ще раз."
            print("Search error:", error)
        }

        isLoading = false
    }

    func selectFromHistory(term: String) {
        searchQuery = term
        Task { await search() }
    }

    private func loadHistory() {
        let defaults = UserDefaults.standard
        searchHistory = defaults.stringArray(forKey: historyKey) ?? []
    }

    private func saveHistory() {
        UserDefaults.standard.set(searchHistory, forKey: historyKey)
    }

    private func updateHistory(with term: String) {
        searchHistory.removeAll { $0.caseInsensitiveCompare(term) == .orderedSame }
        searchHistory.insert(term, at: 0)

        if searchHistory.count > 10 {
            searchHistory = Array(searchHistory.prefix(10))
        }

        saveHistory()
    }
}
